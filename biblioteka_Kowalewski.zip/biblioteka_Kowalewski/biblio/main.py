from manage_book import *
from manage_customer import *
from datetime import date
import random
if __name__ == '__main__':
    #addbook(random.randint(104,1000),'Palka','Wykłady z kombinatoryki', '452', '1997-10-09', date.today())
    #addcustomer(random.randint(1000,9999),'Marian Mariuszowski','mariuszowski123@gmail.com','987123456', date.today(), date.today(), 'Majowa', 'Bialystok','Poland')
    rent_book(1972,'Palka')
    #delbook_id(139)
    #delbook_title('Wyklady z kombinatoryki')
    #delcust_name('Marian Mariuszowski')

