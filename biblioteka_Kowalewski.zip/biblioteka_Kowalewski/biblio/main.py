from add_book import *
import random
if __name__ == '__main__':
    addbook(random.randint(104,1000),'Palka','Wykłady z kombinatoryki', 452, '1997-10-09', date.today())


