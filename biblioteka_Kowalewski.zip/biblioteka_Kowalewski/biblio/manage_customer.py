import csv
import random
from datetime import date


def addcustomer(cust_id,name,email,phone,created,updated,street,city,country):
    with open('biblio/customer.csv', mode='a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([cust_id,name,email,phone,created,updated])
    with open('biblio/address.csv', mode='a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([cust_id,street,city,country])

def delcust_id(del_id):
    try:
        with open('biblio/customer.csv', 'r', newline='') as file:
            reader = csv.reader(file)
            lines = list(reader)
    except FileNotFoundError:
        print("Plik nie istnieje.")
        return
    
    updated_lines = [line for line in lines if line[0] != str(del_id)]
    
    try:
        with open('biblio/customer.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(updated_lines)
        print(f"Linia z ID {del_id} została usunięta z pliku.")
    except Exception as e:
        print(f"Wystąpił błąd podczas zapisywania do pliku: {e}")

def delcust_name(del_name):
    try:
        with open('biblio/customer.csv', 'r', newline='') as file:
            reader = csv.reader(file)
            lines = list(reader)
    except FileNotFoundError:
        print("Plik nie istnieje.")
        return
    
    updated_lines = [line for line in lines if line[1] != str(del_name)]
    
    try:
        with open('biblio/customer.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(updated_lines)
        print(f"Linia z tytułem {del_name} została usunięta z pliku.")
    except Exception as e:
        print(f"Wystąpił błąd podczas zapisywania do pliku: {e}")