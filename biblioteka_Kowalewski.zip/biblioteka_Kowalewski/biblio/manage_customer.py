import csv
import random
from datetime import date


def addcustomer(cust_id,name,email,phone,created,updated,street,city,country):
    with open('customer.csv', mode='a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([cust_id,name,email,phone,created,updated])
    with open('address.csv', mode='a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([cust_id,street,city,country])
    with open(f'database/{cust_id}.txt', mode='w') as cust_book_info_file:
        print(f"Utworzono plik {cust_id}.txt")

def rent_book(cust_id,book_title):
    file_content = []
    with open(f'database/{cust_id}.txt', mode='r') as cust_book_info_file:
        zawartosc = cust_book_info_file.read()
        file_content = zawartosc.split()
    with open(f'database/{cust_id}.txt', mode='w') as cust_book_info_file:
        for i in file_content:
            cust_book_info_file.write(i)
            cust_book_info_file.write(f'Wypożyczono książkę o tytule: {book_title}')

def delcust_id(del_id):
    try:
        with open('customer.csv', 'r', newline='') as file:
            reader = csv.reader(file)
            lines = list(reader)
    except FileNotFoundError:
        print("Plik nie istnieje.")
        return
    
    updated_lines = [line for line in lines if line[0] != str(del_id)]
    
    try:
        with open('customer.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(updated_lines)
        print(f"Linia z ID {del_id} została usunięta z pliku.")
    except Exception as e:
        print(f"Wystąpił błąd podczas zapisywania do pliku: {e}")

def delcust_name(del_name):
    try:
        with open('customer.csv', 'r', newline='') as file:
            reader = csv.reader(file)
            lines = list(reader)
    except FileNotFoundError:
        print("Plik nie istnieje.")
        return
    
    updated_lines = [line for line in lines if line[1] != str(del_name)]
    
    try:
        with open('customer.csv', 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(updated_lines)
        print(f"Linia z tytułem {del_name} została usunięta z pliku.")
    except Exception as e:
        print(f"Wystąpił błąd podczas zapisywania do pliku: {e}")