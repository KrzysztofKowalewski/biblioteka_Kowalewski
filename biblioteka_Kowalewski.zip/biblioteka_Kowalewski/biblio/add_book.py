import csv
import random
from datetime import date


def addbook(book_id,book_author,book_title,book_pages,book_created,book_updated):
    with open('book.csv', mode='a', newline='') as csv_file:
        # book_id = random.randint(103,1000)
        # book_author = input("Podaj nazwę autora książki: ")
        # book_title = input("Podaj nazwę książki: ")
        # book_pages = int(input("Podaj ilość stron tej książki: "))
        # book_created = input("Podaj datę wydania książki w formacie RRRR-MM-DD: ")
        # book_updated = date.today()
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([book_id,book_author,book_title,book_pages,book_created,book_updated])

